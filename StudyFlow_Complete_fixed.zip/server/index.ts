import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import { createClient } from "@supabase/supabase-js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SUPABASE_URL = 'https://prevbislidnkafpepvsa.supabase.co';
const ADMIN_EMAIL = 'studyflow2012@gmail.com';

// Service-role client for admin-only routes. This key must NEVER be sent to
// the browser — it bypasses row-level security entirely. It's only used
// here, server-side, and only after verifying the caller is the admin.
// Set SUPABASE_SERVICE_ROLE_KEY in your hosting platform's environment
// variables (Supabase dashboard → Project Settings → API → service_role key).
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const sbAdmin = serviceKey ? createClient(SUPABASE_URL, serviceKey) : null;

// Verifies the request's bearer token belongs to a real, currently-valid
// session AND that the session's email matches the admin email. Returns the
// verified user, or null if the caller isn't the admin.
async function requireAdmin(req: express.Request): Promise<boolean> {
  if (!sbAdmin) return false;
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return false;
  const { data, error } = await sbAdmin.auth.getUser(token);
  if (error || !data?.user) return false;
  return data.user.email === ADMIN_EMAIL;
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json());

  // ── Canvas LMS proxy ───────────────────────────────────────────────────
  // Canvas API tokens can't be used directly from the browser (CORS), so
  // this proxies the request server-side instead.
  app.post('/api/canvas', async (req, res) => {
    const { canvasUrl, token, path: canvasPath } = req.body || {};
    if (!canvasUrl || !token || !canvasPath) {
      return res.status(400).json({ error: 'Missing parameters' });
    }
    const base = `https://${String(canvasUrl).replace(/^https?:\/\//, '').replace(/\/$/, '')}`;
    try {
      const canvasRes = await fetch(`${base}${canvasPath}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await canvasRes.json();
      res.status(canvasRes.status).json(data);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Admin routes (service-role, gated behind requireAdmin) ─────────────
  app.get('/api/admin/users', async (req, res) => {
    if (!(await requireAdmin(req))) return res.status(403).json({ error: 'Forbidden' });
    const { data, error } = await sbAdmin!.auth.admin.listUsers();
    if (error) return res.status(500).json({ error: error.message });
    res.json({ users: data.users });
  });

  app.get('/api/admin/user-details/:userId', async (req, res) => {
    if (!(await requireAdmin(req))) return res.status(403).json({ error: 'Forbidden' });
    const { userId } = req.params;
    const [settings, assignments, commitments, history] = await Promise.all([
      sbAdmin!.from('user_settings').select('*').eq('user_id', userId).single(),
      sbAdmin!.from('assignments').select('*').eq('user_id', userId),
      sbAdmin!.from('commitments').select('*').eq('user_id', userId),
      sbAdmin!.from('timing_history').select('*').eq('user_id', userId),
    ]);
    res.json({
      settings: settings.data,
      assignments: assignments.data,
      commitments: commitments.data,
      history: history.data,
    });
  });

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all routes
  app.get("*", (_req, res) => {
    // Don't serve index.html for API routes or static assets
    if (_req.path.startsWith("/.netlify") || _req.path.startsWith("/api")) {
      return res.status(404).send("Not found");
    }
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
